import React from 'react'
import { NavLink } from 'react-router-dom'
import { useData } from '../../contexts/DataContext'
import './Sidebar.css'

export default function Sidebar() {
  const { stats, zones, vehicles, collectors } = useData()
  return (
    <aside className="sidebar">
      <div className="sidebar__section">
        <div className="sidebar__section-title">Navigation</div>
        <ul className="sidebar__nav-list">
          <li>
            <NavLink to="/" end className={({ isActive }) => `sidebar__nav-item ${isActive ? 'active' : ''}`}>
              <span className="sidebar__nav-item-icon">📊</span>
              Tableau de bord
            </NavLink>
          </li>
          <li>
            <NavLink to="/planning" className={({ isActive }) => `sidebar__nav-item ${isActive ? 'active' : ''}`}>
              <span className="sidebar__nav-item-icon">📅</span>
              Planning
              <span className="sidebar__nav-item-badge">{stats?.weekAssignments || 0}</span>
            </NavLink>
          </li>
          <li>
            <NavLink to="/preleveurs" className={({ isActive }) => `sidebar__nav-item ${isActive ? 'active' : ''}`}>
              <span className="sidebar__nav-item-icon">👥</span>
              Préleveurs
              <span className="sidebar__nav-item-badge">{collectors?.length || 0}</span>
            </NavLink>
          </li>
          <li>
            <NavLink to="/vehicules" className={({ isActive }) => `sidebar__nav-item ${isActive ? 'active' : ''}`}>
              <span className="sidebar__nav-item-icon">🚗</span>
              Véhicules
              <span className="sidebar__nav-item-badge">{vehicles?.length || 0}</span>
            </NavLink>
          </li>
          <li style={{ marginTop: '1rem', borderTop: '1px solid #e2e8f0', paddingTop: '1rem' }}>
            <NavLink to="/settings" className={({ isActive }) => `sidebar__nav-item ${isActive ? 'active' : ''}`}>
              <span className="sidebar__nav-item-icon">⚙️</span>
              Éditeur de Données
            </NavLink>
          </li>
          <li>
            <NavLink to="/oracle" className={({ isActive }) => `sidebar__nav-item ${isActive ? 'active' : ''}`}>
              <span className="sidebar__nav-item-icon">🗄️</span>
              Base Oracle
            </NavLink>
          </li>
          <li>
            <a 
              href="http://localhost:8000/api/export/xlsx" 
              className="sidebar__nav-item" 
              download
              title="Télécharger l'attribution de véhicules en format XLSX"
            >
              <span className="sidebar__nav-item-icon">📥</span>
              Télécharger attribution (.xlsx)
            </a>
          </li>
        </ul>
      </div>




    </aside>
  )
}
