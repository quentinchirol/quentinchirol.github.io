import React from 'react'
import { useData } from '../../contexts/DataContext'
import './CalendarView.css'

export default function CalendarView({ filterCollector, filterVehicle, filterZone }) {
  const { getWeekDates, getAssignmentsByDate, changeWeek } = useData()
  const weekDates = getWeekDates()

  return (
    <div className="calendar-view animate-fade-in">
      <div className="calendar-view__header">
        <h3 className="calendar-view__title">📅 Planning</h3>
        <div className="calendar-view__nav">
          <button className="calendar-view__nav-btn" title="Semaine précédente" onClick={() => changeWeek(-7)}>‹</button>
          <button className="calendar-view__nav-btn" title="Semaine suivante" onClick={() => changeWeek(7)}>›</button>
        </div>
      </div>

      <div
        className="calendar-view__grid"
        style={{ '--calendar-cols': weekDates.length }}
      >
        {weekDates.map((day) => {
          let dayAssignments = getAssignmentsByDate(day.date)

          // Apply filters if provided
          if (filterCollector) {
            dayAssignments = dayAssignments.filter(
              a => String(a.collector.id) === String(filterCollector)
            )
          }
          if (filterVehicle) {
            dayAssignments = dayAssignments.filter(
              a => String(a.vehicle.id) === String(filterVehicle)
            )
          }
          if (filterZone) {
            dayAssignments = dayAssignments.filter(
              a => a.zone === filterZone
            )
          }

          return (
            <div className="calendar-view__day" key={day.date}>
              <div className={`calendar-view__day-header ${day.isToday ? 'calendar-view__day-header--today' : ''}`}>
                <div className="calendar-view__day-name">{day.dayName}</div>
                <div className="calendar-view__day-number" style={{ display: 'flex', alignItems: 'baseline', gap: '4px', justifyContent: 'center' }}>
                  <span>{day.dayNumber}</span>
                  <span style={{ fontSize: '0.65rem', textTransform: 'capitalize', color: 'var(--color-text-muted)' }}>
                    {day.monthName}
                  </span>
                </div>
              </div>
              <div className="calendar-view__day-content">
                {dayAssignments.map((assignment) => (
                  <div className="calendar-view__assignment" key={assignment.id}>
                    <div className="calendar-view__assignment-collector">
                      {assignment.collector.avatar} {assignment.collector.name}
                    </div>
                    <div className="calendar-view__assignment-vehicle">
                      🚗 {assignment.vehicle.plate} – {assignment.vehicle.model}
                    </div>
                    <div className="calendar-view__assignment-time">
                      🕐 {assignment.startTime} – {assignment.endTime} · {assignment.stops} arrêts
                    </div>
                  </div>
                ))}
                {dayAssignments.length === 0 && (
                  <div style={{
                    textAlign: 'center',
                    padding: '2em 1em',
                    color: 'var(--color-text-muted)',
                    fontSize: 'var(--font-size-xs)',
                  }}>
                    Aucune affectation
                  </div>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
