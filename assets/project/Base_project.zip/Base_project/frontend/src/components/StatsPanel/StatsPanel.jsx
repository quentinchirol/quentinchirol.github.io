import React from 'react'
import { useData } from '../../contexts/DataContext'
import './StatsPanel.css'

export default function StatsPanel() {
  const { stats, loading, vehicles, collectors } = useData()

  if (loading || !stats || Object.keys(stats).length === 0) return null;
  const statCards = [
    {
      icon: '👥',
      iconClass: 'primary',
      value: collectors?.length || stats.activeCollectors || 0,
      label: 'Préleveurs actifs',
      trend: '',
      trendDir: 'up',
    },
    {
      icon: '🚗',
      iconClass: 'success',
      value: vehicles?.length || stats.totalVehicles || 0,
      label: 'Véhicules',
      trend: '',
      trendDir: 'up',
    },
    {
      icon: '📋',
      iconClass: 'accent',
      value: stats.weekAssignments || 0,
      label: "Total Tournées",
      trend: '',
      trendDir: 'up',
    },
    {
      icon: '🚨',
      iconClass: stats.unassignedTotal > 0 ? 'danger' : 'success',
      value: stats.unassignedTotal || 0,
      label: 'Tournées en échec',
      trend: '',
      trendDir: stats.unassignedTotal > 0 ? 'down' : 'up',
    },
  ]

  return (
    <div className="stats-panel">
      {statCards.map((stat, idx) => (
        <div
          className="stat-card animate-fade-in"
          key={idx}
          style={{ animationDelay: `${idx * 80}ms` }}
        >
          <div className={`stat-card__icon stat-card__icon--${stat.iconClass}`}>
            {stat.icon}
          </div>
          <div className="stat-card__content">
            <span className="stat-card__value">{stat.value}</span>
            <span className="stat-card__label">{stat.label}</span>
            {stat.trend && (
              <span className={`stat-card__trend stat-card__trend--${stat.trendDir}`}>
                {stat.trendDir === 'up' ? '↑' : '↓'} {stat.trend}
              </span>
            )}
          </div>
        </div>
      ))}
    </div>
  )
}
