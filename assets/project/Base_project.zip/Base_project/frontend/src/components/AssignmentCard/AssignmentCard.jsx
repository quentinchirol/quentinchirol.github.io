import React from 'react'
import './AssignmentCard.css'

export default function AssignmentCard({ assignment }) {
  const { collector, vehicle, zone, tourneeType, startTime, endTime, stops, status } = assignment

  let statusClass = 'planifie'
  if (status === 'en cours') statusClass = 'en-cours'
  if (status === 'non assigné') statusClass = 'danger'

  return (
    <div className={`assignment-card assignment-card--${statusClass} animate-fade-in`}>
      <div className="assignment-card__header">
        <div className="assignment-card__collector">
          <div className="assignment-card__avatar">{collector.avatar}</div>
          <div className="assignment-card__collector-info">
            <span className="assignment-card__collector-name">{collector.name}</span>
            <span className="assignment-card__collector-zone">{zone}</span>
          </div>
        </div>
        <span className={`assignment-card__status assignment-card__status--${statusClass}`}>
          {status}
        </span>
      </div>

      <div className="assignment-card__body">
        <div className="assignment-card__detail">
          <span className="assignment-card__detail-label">Véhicule</span>
          <span className="assignment-card__detail-value">🚗 {vehicle.plate}</span>
        </div>
        <div className="assignment-card__detail">
          <span className="assignment-card__detail-label">Modèle</span>
          <span className="assignment-card__detail-value">{vehicle.model}</span>
        </div>
        <div className="assignment-card__detail">
          <span className="assignment-card__detail-label">Type tournée</span>
          <span className="assignment-card__detail-value">{tourneeType}</span>
        </div>
        <div className="assignment-card__detail">
          <span className="assignment-card__detail-label">Capacité</span>
          <span className="assignment-card__detail-value">{vehicle.capacity}</span>
        </div>
      </div>

      <div className="assignment-card__footer">
        <span className="assignment-card__time">
          🕐 {startTime} – {endTime}
        </span>
        <span className="assignment-card__stops">
          📍 {stops} arrêts
        </span>
      </div>
    </div>
  )
}
