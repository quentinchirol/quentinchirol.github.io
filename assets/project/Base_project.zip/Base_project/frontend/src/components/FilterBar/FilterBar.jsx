import React from 'react'
import { useData } from '../../contexts/DataContext'
import './FilterBar.css'

export default function FilterBar({ filters, onFilterChange }) {
  const { collectors, vehicles, zones, currentViewDate, setViewDate } = useData()
  const handleChange = (field) => (e) => {
    onFilterChange({ ...filters, [field]: e.target.value })
  }

  const handleReset = () => {
    onFilterChange({ collector: '', vehicle: '', zone: '' })
  }

  return (
    <div className="filter-bar animate-fade-in">
      <span className="filter-bar__label">🔍 Filtrer par</span>

      <select
        className="filter-bar__select"
        value={filters.collector || ''}
        onChange={handleChange('collector')}
        id="filter-collector"
      >
        <option value="">Tous les préleveurs</option>
        {collectors
          .filter(c => c.status === 'actif')
          .map(c => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
      </select>

      <select
        className="filter-bar__select"
        value={filters.vehicle || ''}
        onChange={handleChange('vehicle')}
        id="filter-vehicle"
      >
        <option value="">Tous les véhicules</option>
        {vehicles
          .filter(v => v.status === 'disponible')
          .map(v => (
            <option key={v.id} value={v.id}>{v.plate} – {v.model}</option>
          ))}
      </select>



      <span className="filter-bar__label" style={{ marginLeft: 'auto' }}>📅 Aller au :</span>
      <input 
        type="date" 
        className="filter-bar__select" 
        style={{ width: '160px' }}
        value={currentViewDate ? new Date(currentViewDate).toISOString().split('T')[0] : ''}
        onChange={(e) => setViewDate(e.target.value)}
      />

      <button className="filter-bar__reset" onClick={handleReset}>
        ✕ Réinitialiser
      </button>
    </div>
  )
}
