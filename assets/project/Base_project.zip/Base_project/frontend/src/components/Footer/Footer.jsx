import React from 'react'
import './Footer.css'

export default function Footer() {
  const year = new Date().getFullYear()

  return (
    <footer className="footer">
      <div className="footer__content">
        <div className="footer__left">
          <div className="footer__brand">LEAV – Gestion des Tournées</div>
          <div className="footer__description">
            Laboratoire de l'Environnement et de l'Alimentation de la Vendée — 
            Outil interne de planification des tournées de prélèvement.
          </div>
        </div>
        <div className="footer__right">
          <a href="https://laboratoire.vendee.fr/" target="_blank" rel="noopener noreferrer" className="footer__link">
            laboratoire.vendee.fr
          </a>
          <span className="footer__separator"></span>
          <span className="footer__copy">© {year} Conseil Départemental de la Vendée</span>
        </div>
      </div>
    </footer>
  )
}
