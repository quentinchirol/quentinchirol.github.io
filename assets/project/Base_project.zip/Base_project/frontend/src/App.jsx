import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Header from './components/Header/Header'
import Sidebar from './components/Sidebar/Sidebar'
import Footer from './components/Footer/Footer'
import Dashboard from './pages/Dashboard/Dashboard'
import Planning from './pages/Planning/Planning'
import Collectors from './pages/Collectors/Collectors'
import Vehicles from './pages/Vehicles/Vehicles'
import DataEditor from './pages/Settings/DataEditor'
import OracleQueries from './pages/Oracle/OracleQueries'
import './App.css'

export default function App() {
  return (
    <div className="app">
      <Header />
      <div className="app__body">
        <Sidebar />
        <main className="app__main">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/planning" element={<Planning />} />
            <Route path="/preleveurs" element={<Collectors />} />
            <Route path="/vehicules" element={<Vehicles />} />
            <Route path="/oracle" element={<OracleQueries />} />
            <Route path="/settings" element={<DataEditor />} />
          </Routes>
        </main>
      </div>
      <Footer />
    </div>
  )
}
