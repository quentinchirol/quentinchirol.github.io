import React, { useState } from 'react';
import './OracleQueries.css';

export default function OracleQueries() {
  const [connectionStatus, setConnectionStatus] = useState(null);
  const [isTesting, setIsTesting] = useState(false);

  const [sqlQuery, setSqlQuery] = useState('');
  const [sqlFilename, setSqlFilename] = useState('mon_export.xlsx');
  const [isExportingSql, setIsExportingSql] = useState(false);

  const [tourneeParams, setTourneeParams] = useState({
    cdgrpe: 'PR',
    dhdebper: '01/10/25',
    dhfinper: '01/01/26',
    filename: 'tournee_export.xlsx'
  });
  const [isExportingTournee, setIsExportingTournee] = useState(false);

  const [exportResult, setExportResult] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');

  // 1. Test de Connexion
  const testConnection = async () => {
    setIsTesting(true);
    setConnectionStatus(null);
    try {
      const res = await fetch('http://localhost:8000/oracle/test_connection');
      const data = await res.json();
      if (res.ok) {
        setConnectionStatus({ success: true, message: data.message });
      } else {
        setConnectionStatus({ success: false, message: data.detail });
      }
    } catch (err) {
      setConnectionStatus({ success: false, message: "Le serveur Backend est injoignable." });
    }
    setIsTesting(false);
  };

  // 2. Export Libre (SQL Custom)
  const handleSqlExport = async (e) => {
    e.preventDefault();
    if (!sqlQuery.trim()) return;

    setIsExportingSql(true);
    setErrorMsg('');
    setExportResult(null);

    try {
      const res = await fetch('http://localhost:8000/oracle/export_oracle_xlsx', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sql_query: sqlQuery, filename: sqlFilename })
      });
      const data = await res.json();
      if (res.ok) {
        setExportResult(data);
      } else {
        setErrorMsg(data.detail || "Erreur de requête SQL");
      }
    } catch (err) {
      setErrorMsg("Impossible de contacter le serveur.");
    }
    setIsExportingSql(false);
  };

  // 3. Export Formulaire Tournées
  const handleTourneeExport = async (e) => {
    e.preventDefault();
    setIsExportingTournee(true);
    setErrorMsg('');
    setExportResult(null);

    try {
      const res = await fetch('http://localhost:8000/oracle/export_tournee', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(tourneeParams)
      });
      const data = await res.json();
      if (res.ok) {
        setExportResult(data);
      } else {
        setErrorMsg(data.detail || "Erreur lors de l'extraction des tournées");
      }
    } catch (err) {
      setErrorMsg("Impossible de contacter le serveur.");
    }
    setIsExportingTournee(false);
  };

  // 4. Download 
  const downloadFile = (filename) => {
    window.open(`http://localhost:8000/oracle/download_oracle_export/${filename}`, '_blank');
  };

  return (
    <div className="oracle-terminal">
      <div className="oracle-terminal__header">
        <h1 className="oracle-terminal__title">Terminal Base Oracle</h1>
        <p className="oracle-terminal__subtitle">
          Interrogez la base de données de production directement en SQL et exportez les résultats au format Excel.
        </p>
      </div>

      <div className="oracle-terminal__layout">
        
        {/* Colonne Gauche : Test + Custom SQL */}
        <div className="oracle-terminal__column">
          <div className="oracle-card oracle-card--status">
            <h2>Statut de la Connexion</h2>
            <p>Vérifiez que le VPN Oracle et le Client ODPI-C sont bien fonctionnels.</p>
            <button 
              className="btn btn-secondary" 
              onClick={testConnection} 
              disabled={isTesting}
            >
              {isTesting ? 'Ping en cours...' : '📡 Tester la connexion'}
            </button>
            {connectionStatus && (
              <div className={`oracle-alert mt-4 oracle-alert--${connectionStatus.success ? 'success' : 'error'}`}>
                {connectionStatus.success ? '✅ Connexion Établie' : '❌ Échec'} - {connectionStatus.message}
              </div>
            )}
          </div>

          <div className="oracle-card">
            <h2>Extraction Tournées Préconfigurées</h2>
            <p className="text-sm">Génère automatiquement la liste des tournées selon les critères de dates.</p>
            <form onSubmit={handleTourneeExport} className="oracle-form">
              <div className="form-group row">
                <div className="form-item">
                  <label>Date de début</label>
                  <input type="text" value={tourneeParams.dhdebper} onChange={e => setTourneeParams({...tourneeParams, dhdebper: e.target.value})} placeholder="DD/MM/YY" />
                </div>
                <div className="form-item">
                  <label>Date de fin</label>
                  <input type="text" value={tourneeParams.dhfinper} onChange={e => setTourneeParams({...tourneeParams, dhfinper: e.target.value})} placeholder="DD/MM/YY" />
                </div>
              </div>
              <div className="form-group">
                <label>Nom du fichier final</label>
                <input type="text" value={tourneeParams.filename} onChange={e => setTourneeParams({...tourneeParams, filename: e.target.value})} />
              </div>
              <button type="submit" className="btn btn-primary" disabled={isExportingTournee}>
                {isExportingTournee ? 'Patinage côté Oracle...' : '⚙️ Lancer la requête Tournées'}
              </button>
            </form>
          </div>
        </div>

        {/* Colonne Droite : Custom SQL & Resultats */}
        <div className="oracle-terminal__column">
          <div className="oracle-card">
            <h2>Requête SQL Libre (RAW)</h2>
            <form onSubmit={handleSqlExport} className="oracle-form">
              <div className="form-group">
                <label>Votre requête (SELECT ... FROM ...)</label>
                <textarea 
                  className="oracle-textarea" 
                  rows={6}
                  placeholder="SELECT * FROM table FETCH FIRST 100 ROWS ONLY"
                  value={sqlQuery}
                  onChange={(e) => setSqlQuery(e.target.value)}
                  required
                />
              </div>
              <div className="form-group">
                <label>Nom du fichier de sortie</label>
                <input 
                  type="text" 
                  value={sqlFilename} 
                  onChange={e => setSqlFilename(e.target.value)}
                />
              </div>
              <button type="submit" className="btn btn-primary" disabled={isExportingSql}>
                {isExportingSql ? 'Exécution SQL en cours...' : '🚀 Exécuter & Exporter vers Excel'}
              </button>
            </form>
          </div>

          {/* Zone de Résultats */}
          {(exportResult || errorMsg) && (
            <div className={`oracle-card ${errorMsg ? 'oracle-card--error' : 'oracle-card--success'}`}>
              <h2>Résultat de la Requête</h2>
              {errorMsg ? (
                <div className="oracle-alert oracle-alert--error">{errorMsg}</div>
              ) : (
                <div className="oracle-result-box">
                  <div className="oracle-result-stat">
                    <span>Lignes retournées :</span>
                    <strong>{exportResult.rows?.toLocaleString() || 0}</strong>
                  </div>
                  <div className="oracle-result-stat">
                    <span>Colonnes :</span>
                    <strong>{exportResult.columns}</strong>
                  </div>
                  <div className="oracle-result-stat">
                    <span>Fichier créé :</span>
                    <strong>{exportResult.filename}</strong>
                  </div>
                  
                  <button 
                    className="btn btn-success mt-4" 
                    style={{ width: '100%' }}
                    onClick={() => downloadFile(exportResult.filename)}
                  >
                    ⬇️ Télécharger le fichier (.xlsx)
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
        
      </div>
    </div>
  );
}
