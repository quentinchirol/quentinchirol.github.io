import React, { useState } from 'react'
import { useData } from '../../contexts/DataContext'
import './Collectors.css'

export default function Collectors() {
  const { collectors, getAssignmentsByCollector } = useData()
  const [selectedCollector, setSelectedCollector] = useState(null)
  return (
    <div className="collectors">
      <div className="collectors__header">
        <h1 className="collectors__title">Préleveurs</h1>
        <p className="collectors__subtitle">
          Liste des préleveurs et leurs prochaines affectations véhicules.
        </p>
      </div>

      <div className="collectors__grid">
        {collectors.map((collector, idx) => {
          const collectorAssignments = getAssignmentsByCollector(collector.id).slice(0, 3)
          const statusClass = collector.status === 'actif'
            ? 'actif'
            : collector.status === 'indisponible'
              ? 'indisponible'
              : 'conge'

          return (
            <div
              className="collector-card animate-fade-in"
              key={collector.id}
              style={{ animationDelay: `${idx * 60}ms` }}
            >
              <div className="collector-card__header">
                <div className="collector-card__avatar">{collector.avatar}</div>
                <div className="collector-card__info">
                  <div className="collector-card__name">{collector.name}</div>
                  <div className="collector-card__zone">{collector.zone}</div>
                </div>
                <span className={`collector-card__status collector-card__status--${statusClass}`}>
                  {collector.status}
                </span>
              </div>

              <div className="collector-card__body">

                {collectorAssignments.length > 0 && (
                  <div className="collector-card__assignments">
                    <div className="collector-card__assignments-title">
                      Prochaines affectations
                    </div>
                    {collectorAssignments.map((a) => (
                      <div className="collector-card__assignment-item" key={a.id}>
                        <span className="collector-card__assignment-date">
                          {new Date(a.date).toLocaleDateString('fr-FR', {
                            weekday: 'short',
                            day: 'numeric',
                            month: 'short',
                          })}
                        </span>
                        <span className="collector-card__assignment-vehicle">
                          🚗 {a.vehicle.plate}
                        </span>
                      </div>
                    ))}
                  </div>
                )}

                {collector.status !== 'actif' && collectorAssignments.length === 0 && (
                  <div className="collector-card__assignments">
                    <div className="collector-card__assignments-title">
                      Statut
                    </div>
                    <div style={{
                      fontSize: 'var(--font-size-xs)',
                      color: 'var(--color-text-muted)',
                      padding: 'var(--spacing-sm) 0',
                    }}>
                      {collector.status === 'indisponible'
                        ? '⚠️ Préleveur actuellement indisponible'
                        : '🏖️ Préleveur en congé'}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
