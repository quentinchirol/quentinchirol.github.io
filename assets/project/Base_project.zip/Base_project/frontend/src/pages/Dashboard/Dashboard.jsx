import React from 'react'
import { Link } from 'react-router-dom'
import StatsPanel from '../../components/StatsPanel/StatsPanel'
import { useData } from '../../contexts/DataContext'
import './Dashboard.css'

export default function Dashboard() {
  const { assignments, loading, error } = useData()

  if (loading) return <div className="dashboard">Chargement des données API...</div>
  if (error) return <div className="dashboard">Erreur de chargement API: {error}</div>

  const unassigned = assignments.filter(a => a.status === 'non assigné')

  // Filter to only display assignments that have been assigned a vehicle
  const globalAssignments = assignments.filter(a => a.status !== 'non assigné')

  return (
    <div className="dashboard">
      <div className="dashboard__welcome">
        <h1 className="dashboard__welcome-title">Tableau de bord Global</h1>
      </div>

      <StatsPanel />

      {unassigned.length > 0 && (
        <div className="dashboard__section dashboard__section--danger" style={{ backgroundColor: '#fff5f5', padding: '1.5rem', borderRadius: '12px', border: '1px solid #feb2b2', marginBottom: '2rem' }}>
          <div className="dashboard__section-header">
            <h2 className="dashboard__section-title" style={{ color: '#e53e3e' }}>
              ⚠️ Alertes d'Affectations ({unassigned.length})
            </h2>
          </div>
          <p style={{ color: '#c53030', marginBottom: '1rem', fontSize: '0.9rem' }}>
            L'algorithme n'a pas pu trouver de véhicule adapté aux contraintes de ces tournées.
          </p>
          <div className="dashboard__overview-table">
            <table style={{ border: '1px solid #fed7d7' }}>
              <thead style={{ backgroundColor: '#fed7d7', color: '#9b2c2c' }}>
                <tr>
                  <th>Date</th>
                  <th>Préleveur</th>
                  <th>Contrainte Restrictive</th>
                  <th>État du Véhicule</th>
                </tr>
              </thead>
              <tbody>
                {unassigned.map((a) => (
                  <tr key={a.id} style={{ backgroundColor: 'white' }}>
                    <td><strong>{a.date}</strong></td>
                    <td>{a.collector.avatar} {a.collector.name}</td>
                    <td style={{ fontWeight: 'bold' }}>{a.tourneeType}</td>
                    <td><span className="badge badge--danger" style={{ backgroundColor: '#fed7d7', color: '#9b2c2c' }}>{a.vehicle.model}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <div className="dashboard__section">
        <div className="dashboard__section-header">
          <h2 className="dashboard__section-title">
            📋 Toutes les affectations réussies
          </h2>
          <Link to="/settings" className="dashboard__section-link">
            Mettre à jour les données →
          </Link>
        </div>

        <div className="dashboard__overview-table">
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Préleveur</th>
                <th>Véhicule Assigné</th>
                <th>Modèle</th>
                <th>Type de Tournée</th>
                <th>Statut</th>
              </tr>
            </thead>
            <tbody>
              {globalAssignments.map((a) => (
                <tr key={a.id}>
                  <td>
                    <strong>
                      {new Date(a.date).toLocaleDateString('fr-FR', {
                        weekday: 'short',
                        day: 'numeric',
                        month: 'short',
                      })}
                    </strong>
                  </td>
                  <td>{a.collector.avatar} {a.collector.name}</td>
                  <td><strong>{a.vehicle.plate}</strong></td>
                  <td>{a.vehicle.model}</td>
                  <td>{a.tourneeType}</td>
                  <td>
                    <span className={`badge badge--success`}>
                      affecté
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
