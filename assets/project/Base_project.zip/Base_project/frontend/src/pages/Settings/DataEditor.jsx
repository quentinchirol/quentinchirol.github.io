import React, { useState, useEffect } from 'react';
import './DataEditor.css';
import { useData } from '../../contexts/DataContext';

export default function DataEditor() {
  const [activeTab, setActiveTab] = useState('vehicules');
  const [file, setFile] = useState(null);
  const [uploadStatus, setUploadStatus] = useState('idle'); // 'idle', 'uploading', 'success', 'error'
  const [message, setMessage] = useState('');
  
  // Data Editor state
  const [gridData, setGridData] = useState([]);
  const [columns, setColumns] = useState([]);
  const [loadingData, setLoadingData] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  
  const tabs = [
    { id: 'vehicules', label: '🚗 Véhicules (Flotte & Préférences)' },
    { id: 'indisponibilite', label: '📅 Indisponibilités' },
    { id: 'preleveurs', label: '👥 Matrice Préleveurs' },
    { id: 'tournees', label: '📋 Base des Tournées Quotidiennes' }
  ];

  // Fetch data on tab change
  useEffect(() => {
    fetchEditorData(activeTab);
    clearUpload();
  }, [activeTab]);

  const fetchEditorData = async (tabId) => {
    setLoadingData(true);
    try {
      const response = await fetch(`http://localhost:8000/api/editor/${tabId}`);
      if (!response.ok) throw new Error("Fichier introuvable ou erreur de lecture.");
      const data = await response.json();
      
      if (data && data.length > 0) {
        setColumns(Object.keys(data[0]));
        setGridData(data);
      } else {
        setGridData([]);
        setColumns([]);
      }
    } catch (err) {
      setGridData([]);
      console.error(err);
    } finally {
      setLoadingData(false);
    }
  };

  const handleCellChange = (rowIndex, column, value) => {
    const newData = [...gridData];
    newData[rowIndex][column] = value;
    setGridData(newData);
  };

  const addRow = () => {
    const emptyRow = {};
    columns.forEach(col => emptyRow[col] = "");
    setGridData([...gridData, emptyRow]);
  };

  const removeRow = (index) => {
    const newData = [...gridData];
    newData.splice(index, 1);
    setGridData(newData);
  };

  const saveGridData = async () => {
    try {
      setUploadStatus('uploading');
      setMessage('Sauvegarde des données modifiées dans le classeur Excel...');
      
      const response = await fetch(`http://localhost:8000/api/editor/${activeTab}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ data: gridData })
      });
      
      const resData = await response.json();
      if (response.ok) {
        setUploadStatus('success');
        setMessage(resData.message || "Sauvegarde réussie et attributions recalculées !");
        setIsEditing(false);
      } else {
        throw new Error(resData.detail || "Erreur de sauvegarde");
      }
    } catch (err) {
      setUploadStatus('error');
      setMessage(`Erreur: ${err.message}`);
    }
  };

  // Upload Handlers
  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setUploadStatus('idle');
      setMessage('');
    }
  };

  const clearUpload = () => {
    setFile(null);
    setUploadStatus('idle');
    setMessage('');
  };

  const handleUpload = async () => {
    if (!file) return;
    try {
      setUploadStatus('uploading');
      setMessage('Mise à jour du ficher Excel complet...');
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('http://localhost:8000/upload', {
        method: 'POST',
        body: formData,
      });
      const data = await response.json();
      if (response.ok) {
        setUploadStatus('success');
        setMessage("Fichier importé avec succès. Les algorithmes sont relancés !");
        fetchEditorData(activeTab); // Rafraichir le tableau interactif
      } else {
        throw new Error(data.error || "Erreur HTTP.");
      }
    } catch (err) {
      setUploadStatus('error');
      setMessage(err.message);
    }
  };

  return (
    <div className="data-editor">
      <div className="data-editor__header">
        <h1 className="data-editor__title">Base de Données & Imports</h1>
        <p className="data-editor__subtitle">
          Sélectionnez l'onglet correspondant à la table que vous souhaitez importer ou modifier manuellement.
        </p>
      </div>

      <div className="data-editor__tabs">
        {tabs.map(tab => (
          <button 
            key={tab.id}
            className={`data-editor__tab ${activeTab === tab.id ? 'data-editor__tab--active' : ''}`}
            onClick={() => setActiveTab(tab.id)}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="data-editor__content">
        <div className="data-editor__grid-card">
          <div className="data-editor__grid-header">
            <h2>Mode Édition Interactive</h2>
            <div className="data-editor__grid-actions">
              {!isEditing ? (
                <button className="btn btn-primary" onClick={() => setIsEditing(true)}>
                  ✏️ Modifier les valeurs
                </button>
              ) : (
                <>
                  <button className="btn btn-secondary" onClick={addRow}>
                    ➕ Ajouter Ligne
                  </button>
                  <button className="btn btn-primary" onClick={saveGridData} disabled={uploadStatus === 'uploading'}>
                    💾 Sauvegarder
                  </button>
                  <button className="btn btn-danger-outline" onClick={() => { setIsEditing(false); fetchEditorData(activeTab); }}>
                    Annuler
                  </button>
                </>
              )}
            </div>
          </div>

          {loadingData ? (
             <div className="p-4 text-center">Extraction des données Excel en cours...</div>
          ) : gridData.length > 0 ? (
            <div className="data-editor__table-container">
              <table className="data-editor__table">
                <thead>
                  <tr>
                    {columns.map(col => <th key={col}>{col}</th>)}
                    {isEditing && <th>Action</th>}
                  </tr>
                </thead>
                <tbody>
                  {gridData.map((row, rIdx) => (
                    <tr key={rIdx}>
                      {columns.map(col => (
                        <td key={col}>
                          {isEditing ? (
                            <input 
                              type="text" 
                              value={row[col] !== null ? row[col] : ""} 
                              onChange={(e) => handleCellChange(rIdx, col, e.target.value)}
                              className="data-editor__input"
                            />
                          ) : (
                            <span>{row[col]}</span>
                          )}
                        </td>
                      ))}
                      {isEditing && (
                        <td>
                          <button className="btn btn-danger-outline btn-sm" onClick={() => removeRow(rIdx)}>🗑️</button>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-4 text-center text-gray-500">Aucune donnée trouvée. Importez un fichier.</div>
          )}
        </div>

        <div className="data-editor__import-card">
          <h2>Mode Importation de Fichier Global</h2>
          <p>La manière la plus sûre et complète pour mettre à jour <strong>{tabs.find(t=>t.id === activeTab).label}</strong> en gardant vos formules, couleurs et onglets intacts.</p>
          
          <div className="settings__upload-box" style={{ marginTop: '1rem' }}>
            <div className="settings__upload-icon">📁</div>
            <p className="settings__upload-text">
              {file ? `Nouveau fichier : ${file.name}` : `Importez votre nouveau ${activeTab === 'vehicules' ? 'vehicules.xlsx' : activeTab === 'indisponibilite' ? 'indisponibilite.xlsx' : activeTab === 'preleveurs' ? 'preleveurs_trimestriel (1).xlsx' : 'Tournee.xlsx'} ici`}
            </p>
            <input 
               type="file" 
               accept=".xlsx" 
               className="settings__file-input" 
               onChange={handleFileChange} 
            />
            <label className="btn btn-secondary settings__browse-btn">Parcourir...</label>
          </div>

          {file && (
             <div className="settings__upload-actions mt-4">
                <button className="btn btn-primary" onClick={handleUpload} disabled={uploadStatus === 'uploading'}>
                  {uploadStatus === 'uploading' ? 'Validation en cours...' : '📤 Appliquer ce fichier'}
                </button>
                <button className="btn btn-danger-outline" onClick={clearUpload}>Annuler</button>
             </div>
          )}

          {message && (
             <div className={`settings__alert settings__alert--${uploadStatus} mt-4`}>
                {message}
             </div>
          )}
        </div>
      </div>
    </div>
  );
}
