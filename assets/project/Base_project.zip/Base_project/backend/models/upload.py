"""
@purpose   : Modèle de réponse de l'endpoint POST /upload
@logic     : Inclut les statistiques de liaison.py exécuté après chaque upload
@decisions : Tous les champs liaison_* sont Optional pour ne pas bloquer si liaison échoue
@references: https://docs.pydantic.dev/latest/
"""

from pydantic import BaseModel
from typing import Optional


class UploadResponse(BaseModel):
    filename: str
    saved_to: str
    liaison_total: Optional[int] = None
    liaison_attribues: Optional[int] = None
    liaison_sans_vehicule: Optional[int] = None
    liaison_output: Optional[str] = None
    liaison_error: Optional[str] = None
