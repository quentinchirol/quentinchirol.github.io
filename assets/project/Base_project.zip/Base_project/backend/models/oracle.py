"""
@AI_SPACE
@purpose   : Modèles Pydantic pour l'endpoint Oracle
@logic     : Définit la structure des données entrantes (Recherches/Exports) et sortantes.
@decisions : Maintien strict de la séparation des préoccupations pour garder le routeur propre.
@references: https://docs.pydantic.dev/latest/
"""
from pydantic import BaseModel

class ExportRequest(BaseModel):
    """Request model for Oracle export"""
    sql_query: str
    filename: str = "oracle_export.xlsx"

class TourneeRequest(BaseModel):
    """Request model for tourneé export with parameters"""
    cdgrpe: str = "PR"
    dhdebper: str = "01/10/25"
    dhfinper: str = "01/01/26"
    filename: str = "tournee_export.xlsx"

class ExportResponse(BaseModel):
    """Response model for Oracle export"""
    status: str
    rows: int
    columns: int
    filename: str
    file_path: str
    exported_at: str

class ConnectionTestResponse(BaseModel):
    """Response model for connection test"""
    status: str
    message: str
