"""
@AI_SPACE
@purpose   : Modèles Pydantic pour l'édition manuelle des fichiers
@logic     : Valide que la requête de mise à jour contient bien une liste de dictionnaires (Lignes excel)
@decisions : Isolé de la logique métier pour rester pur "contrat de données".
@references: https://docs.pydantic.dev/latest/
"""
from pydantic import BaseModel
from typing import List, Dict, Any

class UpdateDataRequest(BaseModel):
    """Payload for updating an Excel sheet via the editor"""
    data: List[Dict[str, Any]]
