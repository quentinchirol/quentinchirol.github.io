from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
from routers.upload import router as upload
from routers.oracle import router as oracle
from routers.assignments import router as assignments
from routers.editor import router as editor

app = FastAPI()

# CORS - allow frontend to call the API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(upload)
app.include_router(oracle)
app.include_router(assignments, prefix="/api")
app.include_router(editor, prefix="/api")


