"""
@AI_SPACE
@purpose   : Logique métier pour la lecture et la mise à jour des cellules Excel depuis l'interface Éditeur.
@logic     : Utilise pandas pour la lecture rapide, et openpyxl pour l'écriture ciblée sans détruire les autres onglets. 
             Déclenche également automatiquement la fonction `run_liaison` après chaque modification.
@decisions : Extraction depuis le routeur pour un code DRY et testable.
@references: https://openpyxl.readthedocs.io/
"""
import pandas as pd
import os
from openpyxl import load_workbook

# Configuration des fichiers
FILES_MAP = {
    "tournees": {"filename": "Tournee.xlsx", "sheet": 0, "skiprows": 0},
    "indisponibilite": {"filename": "indisponibilite.xlsx", "sheet": 0, "skiprows": 0},
    "preleveurs": {"filename": "preleveurs_trimestriel (1).xlsx", "sheet": 0, "skiprows": 0},
    "vehicules": {"filename": "vehicules.xlsx", "sheet": "préférence", "skiprows": 1},
}

DATA_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "_data"))

class EditorFileError(Exception):
    pass

class EditorReadError(Exception):
    pass

def read_editor_data(file_key: str) -> list:
    """Read excel data and format it into a list of dictionaries for the frontend."""
    if file_key not in FILES_MAP:
        raise EditorFileError("File key unknown")
    
    config = FILES_MAP[file_key]
    file_path = os.path.join(DATA_DIR, config["filename"])
    
    if not os.path.exists(file_path):
        return []

    try:
        # Read the file
        df = pd.read_excel(file_path, sheet_name=config["sheet"], skiprows=config["skiprows"])
        
        # Clean column names
        df.columns = df.columns.astype(str).str.replace(r'[\n\r]', ' ', regex=True).str.strip()
        
        # Replace NaN with empty string
        df = df.fillna("")
        
        return df.to_dict(orient="records")
    except Exception as e:
        raise EditorReadError(str(e))

def write_editor_data(file_key: str, data_records: list) -> dict:
    """Overwrite the excel sheet with new records using openpyxl, then trigger recalculation."""
    if file_key not in FILES_MAP:
        raise EditorFileError("File key unknown")
        
    config = FILES_MAP[file_key]
    file_path = os.path.join(DATA_DIR, config["filename"])
    
    if not os.path.exists(file_path):
        raise EditorFileError("Excel file does not exist. Upload it first via the file importer.")
        
    try:
        df_new = pd.DataFrame(data_records)
        sheet_name_to_write = config["sheet"]
        skip = config["skiprows"]
        
        wb = load_workbook(file_path)
        
        # Resolve sheet name if it was index 0
        if isinstance(sheet_name_to_write, int):
            sheet_name_to_write = wb.sheetnames[sheet_name_to_write]
            
        ws = wb[sheet_name_to_write]
        
        # Effacer les anciennes données (uniquement les valeurs) à partir de la ligne des entêtes
        for row in ws.iter_rows(min_row=skip + 1, max_row=ws.max_row, min_col=1, max_col=ws.max_column):
            for cell in row:
                cell.value = None
        
        # Ecrire les nouveaux entetes
        for col_idx, col_name in enumerate(df_new.columns, start=1):
            ws.cell(row=skip + 1, column=col_idx, value=col_name)
            
        # Ecrire les nouvelles valeurs
        for row_idx, row_data in enumerate(df_new.itertuples(index=False), start=skip + 2):
            for col_idx, val in enumerate(row_data, start=1):
                ws.cell(row=row_idx, column=col_idx, value=val)
                
        wb.save(file_path)
                
        # Trigger recalculation automatically!
        from services.liaison import run_liaison
        result = run_liaison(DATA_DIR)
        
        return {
            "message": "Data saved successfully",
            "liaison_output": result.get("output_path", "No output path returned"),
            "liaison_stats": {
                "total": result.get("total"),
                "attribues": result.get("attribues"),
                "sans_vehicule": result.get("sans_vehicule"),
            }
        }
    except Exception as e:
        raise EditorReadError(str(e))
