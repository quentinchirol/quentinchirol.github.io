"""
@purpose   : Router FastAPI pour l'upload de fichiers xlsx
@logic     : POST /upload → sauvegarde du fichier + re-exécution liaison
             La réponse contient les statistiques d'attribution ou l'erreur liaison
@decisions : En cas d'échec de liaison, status HTTP reste 200 mais liaison_error est renseigné
             pour ne pas bloquer l'upload (principe de tolérance).
@references: https://fastapi.tiangolo.com/tutorial/bigger-applications/
"""

from fastapi import APIRouter, UploadFile, File
from models.upload import UploadResponse
from services.upload import save_xlsx
import os

router = APIRouter()


@router.post("/upload", response_model=UploadResponse)
async def upload_xlsx(file: UploadFile = File(...)):
    if not file.filename.endswith(".xlsx"):
        return {"error": "Le fichier doit être au format .xlsx"}

    data_dir = os.path.join(os.path.dirname(__file__), "..", "_data")
    file_path, liaison_result, liaison_error = save_xlsx(file, data_dir)

    if liaison_result:
        return UploadResponse(
            filename=file.filename,
            saved_to=file_path,
            liaison_total=liaison_result["total"],
            liaison_attribues=liaison_result["attribues"],
            liaison_sans_vehicule=liaison_result["sans_vehicule"],
            liaison_output=liaison_result["output_path"],
        )
    else:
        return UploadResponse(
            filename=file.filename,
            saved_to=file_path,
            liaison_error=liaison_error,
        )
