from fastapi import APIRouter, HTTPException, File, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import Optional
import os

from services.oracle import (
    execute_and_export,
    execute_tournee_query,
    OracleConnectionError,
    OracleQueryError,
    OracleExportError,
    get_oracle_connection_string,
    test_connection as service_test_connection
)

router = APIRouter(prefix="/oracle", tags=["oracle"])

# Default exports directory (can be overridden in Docker)
EXPORTS_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "_data"))

from models.oracle import (
    ExportRequest,
    TourneeRequest,
    ExportResponse,
    ConnectionTestResponse
)
@router.post("/export_oracle_xlsx", response_model=ExportResponse)
async def export_oracle_xlsx(request: ExportRequest):
    """
    Execute SQL query on Oracle database and export results to Excel file.
    
    - **sql_query**: SQL query to execute on Oracle database
    - **filename**: Name of the output Excel file (default: oracle_export.xlsx)
    
    Returns:
        ExportResponse with file details and row count
    """
    try:
        # Execute query and export to Excel
        result = execute_and_export(
            sql_query=request.sql_query,
            filename=request.filename,
            exports_dir=EXPORTS_DIR
        )
        
        return ExportResponse(**result)
        
    except OracleConnectionError as e:
        raise HTTPException(status_code=500, detail=f"Connection error: {str(e)}")
    except OracleQueryError as e:
        raise HTTPException(status_code=400, detail=f"Query error: {str(e)}")
    except OracleExportError as e:
        raise HTTPException(status_code=500, detail=f"Export error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")


@router.get("/download_oracle_export/{filename}")
async def download_oracle_export(filename: str):
    """
    Download an exported Excel file from the exports directory.
    
    - **filename**: Name of the Excel file to download
    
    Returns:
        Excel file for download
    """
    # Validate filename to prevent directory traversal
    if ".." in filename or "/" in filename or "\\" in filename:
        raise HTTPException(status_code=400, detail="Invalid filename")
    
    if not filename.endswith(".xlsx"):
        raise HTTPException(status_code=400, detail="File must be .xlsx format")
    
    file_path = os.path.join(EXPORTS_DIR, filename)
    
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail=f"File not found: {filename}")
    
    return FileResponse(
        path=file_path,
        filename=filename,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )


@router.get("/test_connection", response_model=ConnectionTestResponse)
async def test_oracle_connection():
    """
    Test Oracle database connection using environment variables.
    
    Returns:
        Connection test result
    """
    try:
        # Tente une vraie connexion
        message = service_test_connection()
        return ConnectionTestResponse(
            status="success",
            message=message
        )
    except OracleConnectionError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/exports_list")
async def list_exports():
    """
    List all Excel files in the exports directory.
    
    Returns:
        List of available export files
    """
    try:
        os.makedirs(EXPORTS_DIR, exist_ok=True)
        files = [f for f in os.listdir(EXPORTS_DIR) if f.endswith(".xlsx")]
        return {"files": files, "count": len(files)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error listing files: {str(e)}")


@router.post("/export_tournee", response_model=ExportResponse)
async def export_tournee(request: TourneeRequest):
    """
    Execute tourneé query with parameters and export results to Excel file.
    
    - **cdgrpe**: Code groupe (default: 'PR')
    - **dhdebper**: Date début période, format 'DD/MM/YY' (default: '01/10/25')
    - **dhfinper**: Date fin période, format 'DD/MM/YY' (default: '01/01/26')
    - **filename**: Name of the output Excel file (default: tournee_export.xlsx)
    
    Returns:
        ExportResponse with file details and row count
    """
    try:
        result = execute_tournee_query(
            cdgrpe=request.cdgrpe,
            dhdebper=request.dhdebper,
            dhfinper=request.dhfinper,
            filename=request.filename,
            exports_dir=EXPORTS_DIR
        )
        
        return ExportResponse(**result)
        
    except OracleConnectionError as e:
        raise HTTPException(status_code=500, detail=f"Connection error: {str(e)}")
    except OracleQueryError as e:
        raise HTTPException(status_code=400, detail=f"Query error: {str(e)}")
    except OracleExportError as e:
        raise HTTPException(status_code=500, detail=f"Export error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")
