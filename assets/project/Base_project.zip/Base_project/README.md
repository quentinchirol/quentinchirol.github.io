# 🛰️ LEAV - Logiciel de Gestion d'Affectation Véhicules

**LEAV** est une application web modulaire conçue pour automatiser et optimiser l'attribution quotidienne de la flotte de véhicules aux préleveurs de tournées, en tenant compte de contraintes logistiques (Types de véhicules, Capacités, Équipement) et des indisponibilités de calendrier.

---

## 📐 1. Architecture du Système

L'application repose sur une architecture **Monolithe Modulaire** orchestrée par **Docker Compose** :

### 🔹 Backend (`/backend`)
*   **Technologie** : Python 3.11 + **FastAPI**
*   **Moteur Datasource** : **Pandas** (Lecture / Écriture de fichiers Excel sécurisés).
*   **Connexion Oracle** : Permet l'exportation de données de la base Oracle directement.
*   **Restauration / Liaison** :
    *   Lit en temps réel les tournées déclarées vs les véhicules physiques et leurs contraintes.
    *   Expose une API RESTful (`/api/assignments`, `/api/vehicles`, `/api/collectors`).

### 🔹 Frontend (`/frontend`)
*   **Technologie** : React 18 + **Vite**
*   **Styles** : CSS Vanilla (Design Premium et Réactif).
*   **Mécanique d'Affichage** :
    *   **Context API** (`DataContext`) servant de Store global qui agrège les données dynamiques provenant exclusivement de l'API Backend.
    *   Aucune donnée fictive (mock data) n'est conservée dans le frontend afin d’assurer l’intégrité temporelle (règle *Zero-waste* appliquée).

---

## 🗃️ 2. Modèle de Données & Moteur (`_data/`)

Le dossier central pour toute la lecture et écriture dynamique est `backend/_data/`. **Tout fichier uploadé ou généré, qu'il s'agisse d'un export Oracle ou d'un algorithme de liaison, y est consigné.**

### Fichiers Sources d'Entrée (Inputs)
1.  **`vehicules.xlsx`** :
    *   *Feuille préférence* : Profil des véhicules existants (Immatriculation, Modèle, Propriétaire prioritaire).
    *   *Feuille Véhicules dispo* : **Calendrier journalier** où `Disponibilité == 0` bloque l'affectation (ex: maintenance).
2.  **`Tournee.xlsx`** : Informations synchronisées issues d'export Oracle, contenant les ID et les dates d'intervention.

### Fichier Généré (Output Local)
**`attribution_vehicules.xlsx`** : Le fruit de la liaison algorithmique.
*   *Feuille Résumé* : Récapitule de manière granulaire les contraintes journalières d'affectation.
*   *Feuille Attribution* : Consigne l'heure et l'immatriculation assignée par tournée.

### ⚙️ L'Algorithme de Liaison (Cœur)
*   **Règle d'Or** : **1 Préleveur = 1 Véhicule unique par Jour**.
*   **Agrégation de Contraintes** : Permet de combiner de multiples contraintes logistiques issues de différentes interventions sur une même journée pour exiger le véhicule adéquat.
*   **Priorité d'Assignation** : Filtre d'abord les véhicules "Obligatoires" (ex: Contrainte `ATTELAGE` ou `3PLACES`), puis assigne les restes en fonction des véhicules "Tous types" ou des disponibilités.
*   **Calcul Continu** : Dès qu'une nouvelle configuration manuelle (via l'Éditeur) ou qu'un nouvel Export/Upload modifie la configuration, l'API déclenche le recalcul de façon résiliente.

---

## 🖥️ 3. Fonctionnalités de l'Interface

*   **Tableau de bord (Accueil)** : Vue d'ensemble des KPIs (Véhicules totaux, Préleveurs actifs, Alertes d'échecs de liaisons).
*   **Planning Hebdomadaire (`/planning`)** : Affichage 7 jours (Lundi au Dimanche) synchronisé automatiquement avec les dernières missions importées. Comprend un système de filtrage puissant par Préleveur, Véhicule, et Statut.
*   **Éditeur en Ligne (`/settings`)** : Permet de prévisualiser, d'éditer ou de remplacer n'importe quelle cellule d'un fichier source (Tournées, Véhicules, etc.) à la volée, avec sauvegarde asynchrone sécurisée.
*   **Module Oracle (`/oracle`)** : Requêtage de la base de données Oracle, génération d'exports, et téléchargements – tous encapsulés et écrits automatiquement dans le volume `_data`.
*   **Catalogue des Véhicules (`/vehicles`)** : Statuts interactifs avec affichage du tableau prédictif des "retours de maintenance" d'après les calendriers futurs.

---

## 🚀 4. Lancement Rapide

Le projet fonctionne de manière modulaire et cloisonnée avec **Docker Compose**.

1. Installer et démarrer Docker Desktop.
2. Cloner ce dépôt.
3. À la racine du projet, exécuter :

```bash
docker compose up --build
```

*   **🌐 Frontend (Interface Utilisateur)** : [http://localhost:3000](http://localhost:3000)

### 📚 Accéder à la Documentation de l'API

Le backend (FastAPI) génère automatiquement une documentation interactive qui liste toutes les routes, méthodes et paramètres disponibles (Upload, Liaison, Oracle, etc). Vous pouvez même y tester les requêtes en direct !

Une fois les conteneurs démarrés, ouvrez simplement l'une de ces URL dans votre navigateur :
*   **Swagger UI (Interactif)** : [http://localhost:8000/docs](http://localhost:8000/docs)
*   **ReDoc (Format documentation classique)** : [http://localhost:8000/redoc](http://localhost:8000/redoc)

---

💡 *Chaque composant a été codé, factorisé et poli à l'aune de la doctrine "Zero-Waste" : minimalisme absolu, suppression du code mort (mocks data, dossiers résiduels), et centralisation des flux entrants/sortants sur un canal unique (`_data`).*
