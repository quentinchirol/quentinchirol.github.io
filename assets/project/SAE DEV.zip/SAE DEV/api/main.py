from fastapi import FastAPI

# Import des routers
from api.routers import membres
from api.routers import publications
from api.routers import equipes
from api.routers import simulation
from api.routers import collaboration

app = FastAPI(
    title="API Bibliométrie LIAS",
    description="API de gestion et d'analyse bibliométrique",
    version="1.0.0"
)

# Route de test
@app.get("/")
def root():
    return {"message": "API Bibliométrie opérationnelle 🚀"}

# Inclusion des routers
app.include_router(membres.router, prefix="/membres", tags=["Membres"])
app.include_router(publications.router, prefix="/publications", tags=["Publications"])
app.include_router(equipes.router, prefix="/equipes", tags=["Equipes"])
app.include_router(simulation.router, prefix="/simulation", tags=["Simulation"])
app.include_router(collaboration.router, prefix="/collaboration", tags=["Collaboration"])