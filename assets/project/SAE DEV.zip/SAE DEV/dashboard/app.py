import streamlit as st

st.set_page_config(page_title="SAE DEV Dashboard")
st.title("SAE DEV Dashboard")
st.write("Minimal dashboard entrypoint. Add your Streamlit pages under the `pages/` folder.")
