# Les imports de librairies et annonce des paramètres nécessaires pour se connecter à la base de données
import csv
import mysql.connector
from datetime import datetime

# Paramètres pour se connecter à la base de données MySQL
user = "root"  # Nom d'utilisateur pour la connexion MySQL
password = ""  # Mot de passe pour la connexion MySQL (ici on en a pas)
nom_base_principal = "selmarin-tda"  # Nom de la base de données MySQL à utiliser

# Les fonctions définies pour faire fonctionner le programme YESSIR

# Fonction pour vérifier la connexion à la base de données MySQL
def check_connection(db):
    # Vérifie si la connexion à la base de données est active, sinon essaie de se reconnecter
    if db is None or not db.is_connected():
        print("Connexion MySQL fermée ou non disponible. Tentative de reconnexion...")
        try:
            # Tentative de reconnexion à la base de données (3 essais avec un délai de 2 secondes entre chaque)
            db.reconnect(attempts=3, delay=2)
            print("Reconnexion réussie !")
        except mysql.connector.Error as err:
            # Si il y a une erreur après les tentatives de reconnexion on arrete le programme
            print(f"Erreur de reconnexion : {err}")
            exit(1)

################--------------------------------------------#####################
# Requête pas utilisée actuellement, peut-être réservée pour une interface Tkinter ?
def requete_sql(requete, db):
    try:
        # Exécute la requête SQL et affiche les résultats
        cursor = db.cursor()
        cursor.execute(requete)
        resultats = cursor.fetchall()
        for keys in resultats:
            print(keys)
    except:
        # Si une erreur se produit, affiche un message générique
        print("yes")
################---------------------------------------------#####################

# Fonction pour insérer des données dans la base de données
def insert_sql(requete, db, valeurs):
    try:
        # Vérifie la connexion avec la def d'avant
        check_connection(db)
        c = db.cursor()
        # Exécute la requête d'insertion avec les valeurs données
        c.execute(requete, valeurs)
        db.commit()  # Applique les changements dans la base de données
        print("Insertion réussie !")  # Confirmation de l'insertion réussie
    except Exception as e:
        # Si une erreur survient lors de l'insertion, affiche le message d'erreur
        print(f"Erreur: {e}")

# Programme principal pour traiter les fichiers CSV et insérer les données dans la base de données

# Paramètres de connexion à la base de données MySQL
params = {"host": "localhost", "user": user, "password": password, "database": nom_base_principal}
# Se connecter à la base de données MySQL
db = mysql.connector.connect(**params)        

# Dictionnaire contenant les formats de requêtes SQL pour chaque type de table
requete_format = {
    "entree" : "INSERT INTO {} VALUES (%s, %s, %s, %s, %s)",  # Format pour la table "entree"
    "saunier" : "INSERT INTO {} VALUES (%s, %s, %s, %s)",      # Format pour la table "saunier"
    "client" : "INSERT INTO {} VALUES (%s, %s, %s, %s)",        # Format pour la table "client"
    "sortie" : "INSERT INTO {} VALUES (%s, %s, %s)",            # Format pour la table "sortie"
    "concerner" : "INSERT INTO {} VALUES (%s, %s, %s)",         # Format pour la table "concerner"
}

# Liste des noms des fichiers CSV à traiter
fichier = ["client", "entree", "saunier", "sortie"]

# Parcours chaque fichier CSV dans la liste
for i in range(len(fichier)):
    print(fichier[i])  # Affiche le nom du fichier actuel
    
    with open(fichier[i] + ".csv", mode='r', encoding='utf-8') as file:
        # Ouvre le fichier CSV en mode lecture
        csv_reader = csv.reader(file, delimiter=';')
        # Formate la requête SQL pour la table correspondante
        requete = requete_format[fichier[i]].format(fichier[i].upper())
        nom_cologne = next(csv_reader)  # Lit la première ligne du CSV AKA l'entête

        for row in csv_reader:  # Parcours les lignes suivantes du fichier CSV
            if fichier[i] == "entree":  # Si la table est "entree"
                # Convertit la date du format "jour/mois/année" en format "année-mois-jour heure:minute:seconde"
                row[1] = datetime.strptime(row[1], "%d/%m/%Y").strftime("%Y-%m-%d %H:%M:%S")
            if fichier[i] == "sortie":  # Si la table est "sortie"
                # Convertit la date de sortie au même format
                row[1] = datetime.strptime(row[1], "%d/%m/%Y").strftime("%Y-%m-%d %H:%M:%S")
                # Prépare les tuples à insérer dans les tables "sortie" et "concerner"
                tuple1 = [row[0], row[1], row[2]] 
                tuple2 = [row[3], row[0], row[4]] 
                # Ca les insère dans les tables
                insert_sql(requete_format["sortie"].format("SORTIE"), db, tuple(tuple1))
                insert_sql(requete_format["concerner"].format("CONCERNER"), db, tuple(tuple2))
            else:  # Pour les autres tables on insère directement les données dans la base
                insert_sql(requete, db, tuple(row))
        db.close()  # Ferme le tout quand c'est fini
