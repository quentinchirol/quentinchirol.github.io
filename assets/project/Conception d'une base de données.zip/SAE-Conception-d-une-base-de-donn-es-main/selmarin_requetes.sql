
SELECT client.NumCli, client.nomCli, count(concerner.numPdt) as Nb_Achats, produit.libPdt
from CLIENT , SORTIE , CONCERNER , PRODUIT 
where client.NumCli = sortie.NumCli
and sortie.NumSort = concerner.NumSort
and produit.numPdt = concerner.numPdt
and client.numCli = 1
group by produit.libPdt, client.numCli,client.nomCli

INSERT INTO `client`(`numCli`, `nomCli`, `precisionCli`, `villeCli`) VALUES (12,'CHIROLE','Quentin','BORDEAUX')

UPDATE `client` SET `nomCli`='CHIROL',`precisionCli`='Quentin',`villeCli`='TOULOUSE' WHERE nomCli = 'CHIROLE'

DELETE from CLIENT where numCli = 12

SELECT client.NumCli, client.nomCli, count(concerner.numPdt) as Nb_Achats, produit.libPdt
from CLIENT , SORTIE , CONCERNER , PRODUIT 
where client.NumCli = sortie.NumCli
and sortie.NumSort = concerner.NumSort
and produit.numPdt = concerner.numPdt
group by produit.libPdt, client.numCli,client.nomCli
having Nb_Achats >=5

"produit achetés dans toutes les années sauf 2024"
SELECT p.numPdt, p.libPdt
FROM PRODUIT p
WHERE p.numPdt NOT IN (
    SELECT c.numPdt
    FROM CONCERNER c, SORTIE S
    where c.numSort = s.numSort
    and YEAR(s.dateSort) = 2023
)

"Cette requête permet de savoir combien de produits ont été vendus (sortis) en 2024 pour chaque type de produit"
SELECT p.numPdt, p.libPdt, SUM(c.qteSort) AS total_vendu
FROM PRODUIT p
JOIN CONCERNER c ON p.numPdt = c.numPdt
JOIN SORTIE s ON c.numSort = s.numSort
WHERE YEAR(s.dateSort) = 2024
GROUP BY p.numPdt, p.libPdt;

"obtenir les produist qui ont un stock faible et donc qu'il faudrait avoir en +"
SELECT numPdt, libPdt, stockPdt
FROM PRODUIT
WHERE stockPdt < 1500; 

"nb total de produits vendus pour chaque produit en 2024 mais avec une vue cette fois-ci"
CREATE OR REPLACE VIEW VenteProduit2024 AS
SELECT p.numPdt, p.libPdt, IFNULL(SUM(c.qteSort), 0) AS total_vendu
FROM PRODUIT p
LEFT JOIN CONCERNER c ON p.numPdt = c.numPdt
LEFT JOIN SORTIE s ON c.numSort = s.numSort
LEFT JOIN PRIX pr ON p.numPdt = pr.numPdt
WHERE (YEAR(s.dateSort) = 2024 OR s.dateSort IS NULL) 
AND (pr.Annee = 2024 OR pr.Annee IS NULL)
GROUP BY  p.numPdt, p.libPdt;

"pour voir ce qui a vendu plus qu'un certain montant avec la vue"
SELECT numPdt, libPdt, total_vendu
FROM VenteProduit2024
WHERE total_vendu > 700;

