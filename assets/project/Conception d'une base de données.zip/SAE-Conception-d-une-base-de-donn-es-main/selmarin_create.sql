CREATE TABLE SAUNIER(
   numSau INT ,
   nomSau VARCHAR(50) NOT NULL,
   prenomSau VARCHAR(50) NOT NULL,
   villeSau VARCHAR(50) NOT NULL,
   PRIMARY KEY(numSau)
)Engine = InnoDB;

CREATE TABLE PRODUIT(
   numPdt INT,
   libPdt VARCHAR(50) NOT NULL,
   stockPdt VARCHAR(50) NOT NULL,
   PRIMARY KEY(numPdt)
)Engine = InnoDB;

CREATE TABLE CLIENT(
   numCli INT AUTO_INCREMENT,
   nomCli VARCHAR(50) NOT NULL,
   precisionCli VARCHAR(50) NOT NULL,
   villeCli VARCHAR(50) NOT NULL,
   PRIMARY KEY(numCli)
)Engine = InnoDB;

CREATE TABLE SORTIE(
   numSort INT,
   dateSort DATETIME NOT NULL,
   numCli INT NOT NULL,
   PRIMARY KEY(numSort),
   FOREIGN KEY(numCli) REFERENCES CLIENT(numCli)
)Engine = InnoDB;

CREATE TABLE ANNEE(
   Annee INT,
   PRIMARY KEY(Annee)
)Engine = InnoDB;

CREATE TABLE ENTREE(
   numEnt INT,
   dateEnt DATETIME NOT NULL,
   qteEnt INT NOT NULL,
   numPdt INT NOT NULL,
   numSau INT NOT NULL,
   PRIMARY KEY(numEnt),
   FOREIGN KEY(numPdt) REFERENCES PRODUIT(numPdt),
   FOREIGN KEY(numSau) REFERENCES SAUNIER(numSau)
)Engine = InnoDB;

CREATE TABLE CONCERNER(
   numPdt INT,
   numSort INT,
   qteSort INT NOT NULL,
   PRIMARY KEY(numPdt, numSort),
   FOREIGN KEY(numPdt) REFERENCES PRODUIT(numPdt),
   FOREIGN KEY(numSort) REFERENCES SORTIE(numSort)
)Engine = InnoDB;

CREATE TABLE PRIX(
   numPdt INT,
   Annee INT,
   PrixAchatParTonne INT NOT NULL,
   PrixVenteParTonne INT NOT NULL,
   PRIMARY KEY(numPdt, Annee),
   FOREIGN KEY(numPdt) REFERENCES PRODUIT(numPdt),
   FOREIGN KEY(Annee) REFERENCES ANNEE(Annee)
)Engine = InnoDB;
